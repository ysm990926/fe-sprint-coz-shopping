

const Footer = () =>{
    return <div className="footer">
        <div>개인정보 처리방침 | 이용약관 </div>
    <div>All rights reserved @ Codestates</div>
    </div>
}

export default Footer